package com.kiet.AIML_2A_SPRING;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aiml2ASpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aiml2ASpringApplication.class, args);
	}

}
