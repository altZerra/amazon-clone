package com.kiet.AIML_2A_SPRING;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aiml2ASpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
